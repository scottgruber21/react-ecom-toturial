import React from 'react'
const Error = () => {
  return <h4>error element</h4>
}

export default Error
