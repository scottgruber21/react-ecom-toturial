import React from 'react'

const Loading = () => {
  return <h4>loading element</h4>
}

export default Loading
