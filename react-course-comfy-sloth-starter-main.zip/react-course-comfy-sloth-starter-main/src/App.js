import React from 'react'
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom'
import { Navbar, Sidebar, Footer } from './components'

function App() {
  return <h4>comfy sloth starter</h4>
}

export default App
